#Pairs game experiment

Developed experiment for Charlotte Groombridge

##Ticket

7033

##Description

 * Intro page + end pages
 * Easy phase
 	- 4 x 4 grid
 	- Match card pairs
 * Hard phase
 	- 4 x 7 grid
 	- Match card pairs
 * Record to datafile - two rows on how quick they took

##Features

 * Clickable pairs
 * Fully customisable text and screen options
 	* Uses a screen generator class under psych_lib.py